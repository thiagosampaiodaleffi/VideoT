const express = require('express');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const fs = require('fs');

const upload = multer({ dest: 'uploads/' });
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Ensure folders
['uploads','public'].forEach(d => { if(!fs.existsSync(d)) fs.mkdirSync(d); });

// Simulated export: accept files, respond with a placeholder video URL
app.post('/export', upload.array('files'), async (req, res) => {
  try {
    const files = req.files || [];
    // In a real server we'd process with FFmpeg. Here we simulate by returning a static sample video URL.
    // You can replace sampleUrl with your own hosted file later.
    const sampleUrl = 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4';
    // Save metadata for audit (optional)
    const meta = { received: files.map(f => ({ originalname: f.originalname, size: f.size })), timestamp: Date.now() };
    fs.writeFileSync(path.join('public', `last_export_${Date.now()}.json`), JSON.stringify(meta, null, 2));
    return res.json({ success: true, url: sampleUrl, message: 'Export simulated. Use this URL as the exported video.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'export failed', details: err.message || err });
  }
});

app.get('/', (req, res) => res.send('VideoT simulated backend is running. POST /export to simulate video export.'));
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`VideoT simulated backend running on port ${PORT}`));
