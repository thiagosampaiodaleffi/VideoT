VideoT - Simulated Backend (no FFmpeg)
--------------------------------------

This backend simulates video export: it accepts uploaded files and immediately returns a public sample video URL.
Purpose: allow testing the full UI/UX without heavy server processing or FFmpeg requirements.

Quick start:
  cd backend
  npm install
  node server.js

The server listens on http://localhost:4000
POST /export accepts form-data 'files' and responds with JSON { success: true, url: 'https://...' }
