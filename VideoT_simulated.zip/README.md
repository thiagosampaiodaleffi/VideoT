VideoT — Editor de Vídeo (Simulado)
===================================

Este repositório contém uma versão *simulada* do VideoT — um editor de vídeo completo em UX, mas que NÃO processa vídeos no servidor.
Em vez disso, o backend responde com um vídeo de exemplo público para simular o fluxo de exportação.

Ideal para deploy em Railway (plano gratuito) e testes da interface sem custo.

Como testar localmente:
1. Backend:
   cd backend
   npm install
   node server.js
   # backend disponível em http://localhost:4000
2. Frontend:
   cd frontend
   npm install
   npm start
   # frontend em http://localhost:3000

Deploy no Railway:
- Faça upload deste repositório no GitHub.
- No Railway, escolha 'New Project' -> 'Deploy from GitHub' e conecte o repositório.
- Configure duas services: backend (root: backend, start: npm start) and frontend (root: frontend, start: npm start).
- Ou use o botão Deploy on Railway (se adicionar o arquivo railway.json).

Observação: esta versão é intencionalmente sem FFmpeg para garantir compatibilidade com o plano gratuito do Railway.
