import React, { useState } from 'react';

export default function App() {
  const [clips, setClips] = useState([]);
  const [exporting, setExporting] = useState(false);
  const [resultUrl, setResultUrl] = useState(null);

  function handleFiles(e) {
    const files = Array.from(e.target.files || []);
    const newClips = files.map(f => ({ id: `clip_${Date.now()}_${f.name}`, file: f, name: f.name, size: f.size }));
    setClips(prev => [...prev, ...newClips]);
  }

  function removeClip(id) { setClips(prev => prev.filter(c => c.id !== id)); }

  async function exportProject() {
    if (clips.length === 0) return alert('Adicione clipes antes de exportar');
    setExporting(true);
    setResultUrl(null);
    try {
      const form = new FormData();
      clips.forEach(c => form.append('files', c.file, c.name));
      const resp = await fetch((process.env.REACT_APP_API_URL || 'http://localhost:4000') + '/export', { method: 'POST', body: form });
      const data = await resp.json();
      if (data && data.url) { setResultUrl(data.url); } else { alert('Erro: ' + JSON.stringify(data)); }
    } catch (err) { console.error(err); alert('Erro ao exportar'); } finally { setExporting(false); }
  }

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>VideoT — Editor (Simulado)</h1>
      <p>Fluxo completo funcionando. Export é simulado: um vídeo de exemplo será retornado.</p>
      <div style={{ marginBottom: 10 }}>
        <input type="file" accept="video/*" multiple onChange={handleFiles} />
        <button onClick={exportProject} disabled={exporting} style={{ marginLeft: 8 }}>{exporting ? 'Exportando...' : 'Exportar'}</button>
      </div>

      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <h3>Clips adicionados</h3>
          {clips.map(c => (
            <div key={c.id} style={{ padding: 8, border: '1px solid #ddd', marginBottom: 8 }}>
              <div style={{ fontSize: 14 }}>{c.name}</div>
              <div style={{ fontSize: 12, color: '#666' }}>{(c.size/1024/1024).toFixed(2)} MB</div>
              <button onClick={() => removeClip(c.id)} style={{ marginTop: 6 }}>Remover</button>
            </div>
          ))}
        </div>
        <div style={{ width: 360 }}>
          <h3>Preview</h3>
          {resultUrl ? (
            <div>
              <p>Arquivo exportado (simulado):</p>
              <video src={resultUrl} controls style={{ width: '100%' }} />
            </div>
          ) : (
            <p>Nenhum vídeo exportado ainda.</p>
          )}
        </div>
      </div>
    </div>
  );
}
